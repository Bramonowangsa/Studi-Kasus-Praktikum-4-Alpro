using namespace std;

class Proses{
  public:
    void cetak(){
      cout << "You do Processing \n";
    }
    void getData(){
      ambil_data.open("api_data.txt");
      bool Jumlah_tabungan = true;
      while(!ambil_data.eof()){
        if(jumlah_tabungan){
          ambil_data >> jumlah_tabungan;
        }
        else {
          ambil_data >> pengeluaran_bulan;
        }
      }
      ambil_data.close();
    }

    void tofile(){
      float tabungan=jumlah_tabungan;
      float pengeluaran=pengeluaran_bulan;
      float total=jumlah_tabungan-pengeluaran_bulan;
      
      tulis_data.open("api_data.txt");
      tulis_data << tabungan << endl;
      tulis_data << pengeluaran << endl;
      tulis_data << total << endl;
      tulis_data.close();
    }
  private :
    ifstream ambil_data;
    ofstream tulis_data;
    int jumlah_tabungan;
    int pengeluaran_bulan;
    int total_pengeluaran;
    int tabungan;
    int pengeluaran;
    int total;
};