using namespace std;

class Proses{
  public:
    void getData(){
      ambil_data.open("api_data.txt");
      ambil_data>>uang_perbulan;
      ambil_data.close();
      total_pengeluaran=0;
      uang_saatini=0;
      cout<<"Jumlah Bulan : ";
      cin>>n;
      for(int i=1;i<=n;i++){
        tulis_data.open("api_data.txt");
        bulan_ini=uang_perbulan;
        cout<<"Pengeluaran bulan Ke- "<<i<<" : ";
        cin>>pengeluaran_bulan;
        total_pengeluaran=total_pengeluaran+pengeluaran_bulan;
        uang_saatini=bulan_ini-total_pengeluaran;
        tulis_data<<pengeluaran_bulan<<endl;
        }
        tulis_data.close();
    }
    void toFile(){
      tulis_data.open("api_data.txt");
      tulis_data<<bulan_ini<<endl;
      tulis_data<<total_pengeluaran<<endl;
      tulis_data<<uang_saatini<<endl;
    }
  private :
    ifstream ambil_data;
    ofstream tulis_data;
    int uang_perbulan;
    int pengeluaran_bulan;
    int total_pengeluaran;
    int uang_saatini;
    int bulan_ini;
    int n;
};