using namespace std;

class input {
  public :
    void cetak(){
      cout << "Aplikasi Tabungan\n";
      cout << "1) Uang Perbulan\n";
      cout << "2) Pengeluaran Perbulan\n";
      cout << "3) Total Tabungan Sekarang\n";
      cout << "Uang Perbulan "; cin >>jumlah_tabungan;
      cout << "Pengeluaran Perbulan "; cin >>pengeluaran_perbulan;
     

    }
  void toFile(){
    tulis_data.open("api_data.txt");
    tulis_data <<jumlah_tabungan<<endl;
    tulis_data <<pengeluaran_perbulan<<endl;
   
    tulis_data.close();
  }
  private:
  ofstream tulis_data;
  int jumlah_tabungan, pengeluaran_perbulan, ;
};