using namespace std;

class Output {
  public :
    void cetak(){
      cout << " Total Pengeluaran = Rp." << data_file[1] << endl;
      cout << " Uang Tabungan Saat Ini = Rp. " << data_file[2]<<endl;
      }

    void getData(){
      ambil_data.open("api_data.txt");
      while(!ambil_data.eof()){
        ambil_data >> data_file[index];
        index += 1;
        }
        ambil_data.close();
    }
  private :
    ofstream tulis_data;
    ifstream ambil_data;
    int data_file[30];
    int index = 0;
};