using namespace std;

class input {
  public :
    void cetak(){
      cout << "Uang Perbulan "; cin >>uang;
    }
    void toFile(){
    tulis_data.open("api_data.txt");
    tulis_data <<uang;
    tulis_data.close();
  }
  private:
  ofstream tulis_data;
  int uang ;
};